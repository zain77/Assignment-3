from django.urls import path
from . import views

urlpatterns = [
    #/library/
    path('', views.index, name='index'), #index page

    #users
    path('users/', views.users, name='users'), #users page

    #/users/3/
    path('users/<int:user_id>/', views.detail, name='detail'), #details page
]