from django.db import models

# Create your models here.
class User(models.Model): #Django creates a unique column and sets it as primary key by default
    uname = models.CharField(max_length=250)
    rollno = models.CharField(max_length=250)
    age = models.CharField(max_length=250)
    school = models.CharField(max_length=250)

    def __str__(self):
        return self.uname + ' - ' + self.school #display user's name and school

class Book(models.Model): #Django creates a unique column and sets it as primary key by default
    user = models.ForeignKey(User, on_delete=models.CASCADE)#on_delete=models.CASCADE means that when user is deleted, we need to delete the book as well.
    bname = models.CharField(max_length=250)
    author = models.CharField(max_length=250)
    ISBN = models.CharField(max_length=250)
    genre = models.CharField(max_length=250)
    borrowed_at = models.DateTimeField('Date Issued')
    returned_at = models.DateTimeField('Date Returned')

    def __str__(self):
        return self.bname + ' - ' + self.author #display books ame and author