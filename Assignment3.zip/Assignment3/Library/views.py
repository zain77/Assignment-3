from django.shortcuts import render
from django.http import HttpResponse
from .models import User

# Create your views here.
def index(request): #page for users
    return HttpResponse("<html>"
                        "<h1>Welcome to SEECS Library Management System</h1>"
                        "<h2>Here you can view the books in our library and borrow them</h2>"
                        "<br>"
                        "<br>"
                        "<br>"
                        "<br>"
                        "<br>"
                        "<br>"
                        "<h3>Developed by Zain Gillani</h3>"
    )

def users(request): #Main homepage for library system
    all_users = User.objects.all()
    html = ''
    html += '<h1>Users data is displayed here</h1>'
    html += '<h2>Name-Rollno-School</h2>'
    for user in all_users:
        url = '/user/' + str(user.id) + '/'
        html += '<a href="' + url + '">' + user.uname +'-'+ user.rollno +'-'+ user.school + '</a><br>'
    return HttpResponse(html)

def detail(request, user_id): #deatiled page
    return HttpResponse("You're looking at user no. %s." % user_id)
